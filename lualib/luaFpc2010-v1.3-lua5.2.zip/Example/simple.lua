print("Hello, Lua speaking.");
