print("Hello, Lua speaking again.");

p1,p2 = HelloWorld(1,2,3);
print "Results:";
print (p1, p2);

HelloWorld2();
HelloWorld3();
HelloWorld5();


-- for n in pairs(_G) do print(n) end
